import socket
import elgamal               # Import socket module
import pickle
import copy

port1 = 3469
port2 = 3470

s1 = socket.socket()         # Create a socket object
host1 = socket.gethostname() # Get local machine name
s1.connect((host1, port1))

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name           # Reserve a port for your service.
s.bind(('', port2))        # Bind to the port
s.listen(5)                 # Now wait for client connection.
c, addr = s.accept()     # Establish connection with client.

datad = s1.recv(1024)
data_loaded = pickle.loads(datad)
c.send(datad)
datad2 = c.recv(1024)
data_loaded2 = pickle.loads(datad2)
s1.send(datad2)

while True:
	cipher = c.recv(1024).decode('ascii')
	print ("encrypted text received : ")
	print (cipher)
	print ("\n")
	st = elgamal.reencrypt(data_loaded['publicKey'], cipher)
	print ("re-encrypted text sent : ")
	print (st)
	print ("\n")
	s1.send(st.encode('ascii'))
	cipher = s1.recv(1024).decode('ascii')
	print ("encrypted text received : ")
	print (cipher)
	print ("\n")
	st = elgamal.reencrypt(data_loaded2['publicKey'], cipher)
	print ("re-encrypted text sent : ")
	print (st)
	print ("\n")
	c.send(st.encode('ascii'))  
	    
