#!/usr/bin/python           # This is client.py file

import socket  
import elgamal             # Import socket module
import pickle

key = elgamal.generate_keys()
send_key = key.copy()
s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 3470             # Reserve a port for your service.

s.connect((host, port))
datad = s.recv(1024)
data_loaded = pickle.loads(datad) #data loaded.
del send_key['privateKey']
data_string = pickle.dumps(send_key, -1)
s.send(data_string)

while True:
	st = input("Enter data :  ")
	cipher = elgamal.encrypt(data_loaded['publicKey'], st)
	s.send(cipher.encode('ascii'))
	cipher = s.recv(1024)
	plaintext = elgamal.decrypt(key['privateKey'], cipher)
	print (plaintext)      
              # Close the socket when done
	

