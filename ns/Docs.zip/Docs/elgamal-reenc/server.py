#!/usr/bin/python           # This is server.py file

import socket
import elgamal               # Import socket module
import pickle
import copy

key = elgamal.generate_keys()
send_key = key.copy()
s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 3469            # Reserve a port for your service.
s.bind(('', port))        # Bind to the port

s.listen(5)                 # Now wait for client connection.

c, addr = s.accept()     # Establish connection with client.
#print ("Got connection from"+ addr)
del send_key['privateKey']
data_string = pickle.dumps(send_key, -1)
#c.send(bytes("Thank you for connecting","UTF-8"))
c.send(data_string)
datad = c.recv(1024)
data_loaded = pickle.loads(datad) #data loaded.
while True:
	cipher = c.recv(1024)
	print ("encrypted text : ")
	print (cipher)
	print ("\n")
	plaintext = elgamal.decrypt(key['privateKey'], cipher)
	print (plaintext)
	st = input("Enter data :  ")
	cipher = elgamal.encrypt(data_loaded['publicKey'], st)
	c.send(cipher.encode('ascii'))      
