import socket
import time
#hop 1
#host = socket.gethostname()# Get local machine name
host='192.168.193.192'
print "creating new socket to connect to next hop"
s1 = socket.socket()    # Create a socket object
port = raw_input("enter port next hop(server)")      # port of next hop
s1.connect((host, int(port)))
data=s1.recv(1024)
print data



s = socket.socket()         # Create a socket object

port = raw_input("enter port for prev hop")# Reserve a port for your service.
s.bind(('0.0.0.0', int(port)))        # Bind to the port
s.listen(1)               # Now wait for client connection.
c, addr = s.accept()     # Establish connection with client.
print 'Got connection from hop 1', addr
c.send("connected to hop 2")




while True:
   data_from_prev_hop=c.recv(1024)#get data from prev hop
   time.sleep(1)
   print "data from prev hop: "+data_from_prev_hop
   s1.send(data_from_prev_hop) # send data to next hop
   data_from_next_hop=s1.recv(1024)
   time.sleep(1)
   print "data from next hop: "+data_from_next_hop
   c.send(data_from_next_hop)#send data to prev hop
   
c.close()                # Close the connection

#connected on c

