import socket,subprocess
from Crypto.Cipher import AES
import base64
import sys


################ AES algorithm variables and padding ##########################
BLOCK_SIZE = 32 #define AES block size 
PADDING = '{'  #padding character to be used for enc/dec
pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING #pad the text to be encrypted with sufficient number of '{' chars

#encrypt/encode and decrypt/decode the string
#AES for encryption/decryption and base64 for encode/decode
EncodeAES = lambda c, s: base64.b64encode(c.encrypt(pad(s))) #first encrypt then encode
DecodeAES = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING) #first decode then decrypt

secret = 32*'a' #secret key
cipher=AES.new(secret)  #creating an AES cipher object
###############################################################################


HOST='localhost' #server ip our client will connect to
PORT=11139 #port number to connect to

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM) #create a client socket object
s.connect((HOST,PORT)) #connect to the (host,port) of the server 

encrypted=EncodeAES(cipher,"connected") # encrypt the ACK message and send!
s.send(encrypted)
data = s.recv(1024) #recv command from the server
data = DecodeAES(cipher, data)#decoded the command recvd!
print data#enter uname:pass prompted
stdoutput = raw_input()
encrypted=EncodeAES(cipher,stdoutput)#encrypt the command output and send back to the server
s.send(encrypted)

data = s.recv(1024) #recv command from the server
data = DecodeAES(cipher, data)#decoded the command recvd!
print data

if not (data=="Authenticated!"):
	print "quitting"
	sys.exit(0)

stdoutput = raw_input("enter message : ")
encrypted=EncodeAES(cipher,stdoutput) # encrypt the ACK message and send!
s.send(encrypted)

while 1:
	data = s.recv(2048) #recv command from the server
	data = DecodeAES(cipher, data)#decoded the command recvd!
	if data == "quit" : break
	print "reply: " + data
	
	stdoutput = raw_input("enter message : ")
	
	encrypted=EncodeAES(cipher,stdoutput)#encrypt the command output and send back to the server
	s.send(encrypted)
	
#exit the loop
encrypted=EncodeAES(cipher,"bye") #when loop breaks (ie: when data recvd == quit) send "bye"(encrypted) back to the server
s.send(encrypted)
s.close()#close the socket
