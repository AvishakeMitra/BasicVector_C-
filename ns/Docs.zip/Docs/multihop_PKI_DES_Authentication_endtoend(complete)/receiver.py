import socket               # Import socket module
import time
from Crypto.Cipher import DES
from Crypto.Cipher import AES
import md5
import Crypto
from Crypto.PublicKey import RSA
from Crypto import Random
import ast
from Crypto.Util import asn1
from base64 import b64decode
import random,string
import pickle

def pad(text):
        while len(text) % 8 != 0:
            text += ' '
        return text
######################### DES key creation ###################
def randomword(length): #function to generate a random string of length "length"
	return ''.join(random.choice(string.lowercase) for i in range(length))        
secret=randomword(8)
des = DES.new(secret, DES.MODE_ECB)

#################### passwords loading module ###############
hash1=md5.new("pass1").hexdigest()
hash2=md5.new("lol123").hexdigest()
passwords_file = {"rajat": hash1, "rimal": hash2}
pickle.dump( passwords_file, open( "passwords_file.p", "wb" ) )
passwords = pickle.load( open( "passwords_file.p", "rb" ) )

################### socket creation module ##################

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = raw_input("enter port")              # Reserve a port for your service.
s.bind((host, int(port)))        # Bind to the port
s.listen(1)               # Now wait for client connection.
c, addr = s.accept()     # Establish connection with client.
print 'Got connection from', addr
c.send("conncted to server")

######################### key exchange module ####################
binPubKey=c.recv(1024)#recv client public key in binary
pubKeyObj =  RSA.importKey(binPubKey)#importing client key object from binary key recvd
time.sleep(1)
print "public key recvd  : "+str(pubKeyObj)
secret_to_send = pubKeyObj.encrypt(secret,0)#encrypting secret with client public key
test=''.join(secret_to_send)#converting encrypted tuple to string 
c.send(test)#and sending
c.recv(1024)# receiver connected form client

##################################################################

msg="enter uname:passwd"
c.send(des.encrypt(pad(msg)))

########################### authentication module ################
while(1):
	
	credentials_enc=c.recv(1024)
	uname_pass = des.decrypt(credentials_enc)#decode the data recvd
	uname_pass = uname_pass.strip()
	array = uname_pass.split(":")
	uname=array[0]
	password=array[1]
	time.sleep(1)
	print uname+":"+password+";"
	password=md5.new(password).hexdigest()
	flag=False

	if(uname in passwords):
		
		if(passwords[uname]==password):
			flag=True
			time.sleep(1)
			print "authenticated"
			nextcmd="Authenticated!"
			
		else:
		
			nextcmd="Incorrect Password. Enter again"
			time.sleep(1)
			print nextcmd
	else:
		nextcmd="Incorrect Username. Enter again"
		time.sleep(1)
		print nextcmd

	encrypted=des.encrypt(pad(nextcmd))
	time.sleep(1)
	print "sending status"
	c.send(encrypted)
	if flag==True:
		break;



##################################################################
c.recv(1024)
print "sending!! ack"
encrypted=des.encrypt(pad("session started"))
c.send(encrypted)


while True:
   data=c.recv(1024)
   time.sleep(1)
   print "client message: "+des.decrypt(data)
   next=raw_input("enter message: ")
   c.send(des.encrypt(pad(next)))
   
c.close()                # Close the connection
