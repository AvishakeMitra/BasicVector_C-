import socket
import time
from Crypto.Cipher import DES

def pad(text):
        while len(text) % 8 != 0:
            text += ' '
        return text
des = DES.new('13371337', DES.MODE_ECB)
#hop 1
host = '0.0.0.0'# Get local machine name
print "creating new socket to connect to next hop"
s1 = socket.socket()    # Create a socket object
port = raw_input("enter port for next hop")      # port of next hop
s1.connect((host, int(port)))
data=s1.recv(1024)
print data



s = socket.socket()         # Create a socket object

port = raw_input("enter port for prev hop")      # Reserve a port for your service.
s.bind((host, int(port)))        # Bind to the port
s.listen(1)         # Now wait for client connection.
c, addr = s.accept()     # Establish connection with client.
print 'Got connection from client', addr
#text="connected to hop 1"
#c.send(des.encrypt(pad(text)))




while True:
   data_from_prev_hop=c.recv(1024)#get data from prev hop
   time.sleep(1)
   print "data from prev hop: "+data_from_prev_hop
   s1.send(data_from_prev_hop) # send data to next hop
   data_from_next_hop=s1.recv(1024)
   time.sleep(1)
   print "data from next hop: "+data_from_next_hop
   c.send(data_from_next_hop)#send data to prev hop
   
c.close()                # Close the connection

#connected on c

