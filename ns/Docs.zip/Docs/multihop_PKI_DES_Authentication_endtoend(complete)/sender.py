import socket            # Import socket module
import time
from Crypto.Cipher import DES
from Crypto.Cipher import AES
import base64
import md5
import pickle
import Crypto
from Crypto.PublicKey import RSA
from Crypto import Random
import ast
from Crypto.Util import asn1
from base64 import b64decode

def pad(text):
        while len(text) % 8 != 0:
            text += ' '
        return text



#################### ket generation module #####################
random_generator = Random.new().read
key = RSA.generate(1024, random_generator) #generate pub and priv key
binPrivKey = key.exportKey('DER')
binPubKey =  key.publickey().exportKey('DER')
#publickey = key.publickey() # pub key export for exchange
privKeyObj = RSA.importKey(binPrivKey)
pubKeyObj =  RSA.importKey(binPubKey)
####################### socket creation #######################

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = raw_input("enter port for next hop")# Reserve a port for your service.
s.connect((host, int(port)))

####################### key sharing module #####################
s.send(binPubKey)#send binary public key
data=s.recv(1024)#recv the secret key in encrypted form
secret=privKeyObj.decrypt(data)#decrypt the encrypted key recvd
des = DES.new(secret, DES.MODE_ECB)
s.send(des.encrypt(pad("connected")))
data = s.recv(1024)
data_dec=des.decrypt(data).strip()

####################### authentication module ##################
while(1):
	
	time.sleep(1)
	next=raw_input(data_dec+ "- ")
	s.send(des.encrypt(pad(next)))
	data = s.recv(1024).strip()
	data_dec=des.decrypt(data).strip()
	
	if data_dec=="Authenticated!":
		time.sleep(1)
		print data_dec+"waiting for session to start..."
		break
	

################################################################
encrypted=des.encrypt(pad("session start token"))
s.send(encrypted)

while 1:
	data = s.recv(1024)
	print "recvd : "+des.decrypt(data)
	time.sleep(1)
	next=raw_input("enter message : ")
	s.send(des.encrypt(pad(next)))	

s.close()                     # Close the socket when done
