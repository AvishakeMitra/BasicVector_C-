import socket

s = socket.socket()
host = socket.gethostname()
port = int(raw_input("Enter port number :"))
s.bind((host,port))
s.listen(5)
print "listning..."
c, addr = s.accept()

while True:

	c_msg = c.recv(1024)
	print c_msg
	
	s_msg = raw_input("Enter message :")
	c.send(s_msg)
