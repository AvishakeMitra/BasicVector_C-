import socket

s = socket.socket()
host = socket.gethostname()
port = int(raw_input("Enter port number : "))
s.connect((host,port))

while True :

	c_msg = raw_input("Enter message :")
	s.send(c_msg)
	
	s_msg = s.recv(1024)
	print s_msg
