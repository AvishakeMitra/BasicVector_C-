import socket
from Crypto.Cipher import AES

def  do_encrypt(message) :
	obj = AES.new('aaaaaaaaaaaaaaaa', AES.MODE_CBC, 'This is an IV456')
	message = obj.encrypt(message)
	return message

def do_decrypt(ciphertext):
    obj2 = AES.new('aaaaaaaaaaaaaaaa', AES.MODE_CBC, 'This is an IV456')
    message = obj2.decrypt(ciphertext)
    return message


s = socket.socket()
host = socket.gethostname()
port  = int(raw_input("port:"))
s.bind((host, port))

s.listen(5)



while True :
	c, addr = s.accept()
	print "got connection from", addr
	while 1:
		data=c.recv(1024)		
		dec_data = do_decrypt(data)
		
		dec_data = dec_data.strip()		#remove padding bits
		
		print dec_data
		
		if(dec_data=="bye"):
			break
		
		s_msg = raw_input('\nEnter msg : ')
				
		length = 16 - (len(s_msg) % 16)	#apply padding
		s_msg += " "*length
		
		c_enc =  do_encrypt(s_msg)
		c.send(c_enc)
c.close()
	
	
	
