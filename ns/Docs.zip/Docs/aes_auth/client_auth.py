import socket
from Crypto.Cipher import AES

def  do_encrypt(message) :
	obj = AES.new('aaaaaaaaaaaaaaaa', AES.MODE_CBC, 'This is an IV456')
	ciphertext = obj.encrypt(message)
	return ciphertext

def do_decrypt(ciphertext):
    obj2 = AES.new('aaaaaaaaaaaaaaaa', AES.MODE_CBC, 'This is an IV456')
    message = obj2.decrypt(ciphertext)
    return message


s = socket.socket()
host = socket.gethostname()
port  = int(raw_input("enter port:"))

s.connect((host, port))




while 1:
	ct_msg = raw_input("Enter user name psw : ")
	
	length = 16 - (len(ct_msg) % 16)	#apply padding
	ct_msg += " "*length
		
	ct_enc =  do_encrypt(ct_msg)
	s.send(ct_enc)
	
	
	
	data =  s.recv(1024)
	dec_data = do_decrypt(data)
	
	dec_data = dec_data.strip()		#remove padding bits
	
	print dec_data
	if dec_data == "success":
		break
	

while True:
	c_msg = raw_input("Enter msg : ")
	if(c_msg=="bye"):
		
		length = 16 - (len(c_msg) % 16)	#apply padding
		c_msg += " "*length
		print c_msg
		c_enc =  do_encrypt(c_msg)
		s.send(c_enc)
		break
		
	length = 16 - (len(c_msg) % 16)	#apply padding
	c_msg += " "*length
	print c_msg	
	c_enc =  do_encrypt(c_msg)
	s.send(c_enc)
	
	data =  s.recv(1024)
	dec_data = do_decrypt(data)
	
	dec_data = dec_data.strip()		#remove padding bits
	
	print dec_data
	
s.close()
