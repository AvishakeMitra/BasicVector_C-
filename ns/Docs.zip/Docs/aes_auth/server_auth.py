import socket
from Crypto.Cipher import AES

def  do_encrypt(message) :
	obj = AES.new('aaaaaaaaaaaaaaaa', AES.MODE_CBC, 'This is an IV456')
	message = obj.encrypt(message)
	return message

def do_decrypt(ciphertext):
    obj2 = AES.new('aaaaaaaaaaaaaaaa', AES.MODE_CBC, 'This is an IV456')
    message = obj2.decrypt(ciphertext)
    return message


s = socket.socket()
host = socket.gethostname()
port  = int(raw_input("port:"))
s.bind((host, port))

s.listen(5)

user_psw = {'hemraj':'1234', 'rimal':'2345'}

while True :
	c, addr = s.accept()
	print "got connection from", addr
	
	while 1:
		data =  c.recv(1024)
		dec_data = do_decrypt(data)
	
		dec_data = dec_data.strip()		#remove padding bits
		arr = dec_data.split()	
		print arr
		u_name = arr[0]
		psw = arr[1]
		
		if u_name in user_psw:			#if uname in user_psw:
			if user_psw[u_name] == psw:	#if user_psw[uname]==password
				print "Authenticate"
				flag = "success"
			else:
				print "psw wrong"
				flag ="psw wrong"
		else:
			print "u_name wrong"
			flag = "u_name wrong"
		
		ct_msg = flag
	
		length = 16 - (len(ct_msg) % 16)	#apply padding
		ct_msg += " "*length
		
		ct_enc =  do_encrypt(ct_msg)
		c.send(ct_enc)
	
		if flag == "success":
			break
	
	
	while 1:
		data=c.recv(1024)		
		dec_data = do_decrypt(data)
		
		dec_data = dec_data.strip()		#remove padding bits
		
		print dec_data
		
		if(dec_data=="bye"):
			break
		
		s_msg = raw_input('\nEnter msg : ')
				
		length = 16 - (len(s_msg) % 16)	#apply padding
		s_msg += " "*length
		
		c_enc =  do_encrypt(s_msg)
		c.send(c_enc)
c.close()
	
	
	
