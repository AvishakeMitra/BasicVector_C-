#!/usr/bin/python           # This is server.py file
import Crypto
from Crypto.PublicKey import RSA
from Crypto import Random
import ast
import socket               # Import socket module

port = 12346
random_generator = Random.new().read
key = RSA.generate(1024, random_generator) #generate pub and priv key

#publickey = key.publickey() # pub key export for exchange
binPrivKey = key.exportKey('DER')
binPubKey =  key.publickey().exportKey('DER')

privKeyObj = RSA.importKey(binPrivKey)
6
s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
           
s.bind((host, port))        # Bind to the port

s.listen(5)                 # Now wait for client connection.

c, addr = s.accept()     # Establish connection with client.
bincPubKey = c.recv(1024)#recv client public key in binary
pubcKeyObj =  RSA.importKey(bincPubKey)#importing client key object from binary key recvd
print "public key recvd  : "+str(pubcKeyObj)

c.send(binPubKey)#send binary public key
while True:
   
   toSend = raw_input("Enter message : ")
   toSend = pubcKeyObj.encrypt(toSend,0)#encrypting secret with client public key
   encrypted=''.join(toSend)#converting encrypted tuple to string 
   
   
   c.send(encrypted)
   
   data = c.recv(1024)#recv the secret key in encrypted form
   print 'encrypted message recvd :'+data #ciphertext
   decrypted = privKeyObj.decrypt(data)#decrypt the encrypted key recvd
   print 'decrypted : ', decrypted	
   #print data
   
c.close()                # Close the connection
