#!/usr/bin/python           # This is client.py file

import Crypto
from Crypto.PublicKey import RSA
from Crypto import Random
import ast

import socket               # Import socket module

port = 12346

random_generator = Random.new().read
key = RSA.generate(1024, random_generator) #generate pub and priv key

#publickey = key.publickey() # pub key export for exchange
binPrivKey = key.exportKey('DER')
binPubKey =  key.publickey().exportKey('DER')

privKeyObj = RSA.importKey(binPrivKey)
s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name


s.connect((host, port))
s.send(binPubKey)#send binary public key

binsPubKey=s.recv(1024)#recv client public key in binary
pubsKeyObj =  RSA.importKey(binsPubKey)#importing client key object from binary key recvd

print "public key recvd  : "+str(pubsKeyObj)
while 1:
	data = s.recv(1024)#recv the secret key in encrypted form
	print 'encrypted message recvd :'+data #ciphertext
	decrypted = privKeyObj.decrypt(data)#decrypt the encrypted key recvd
	print 'decrypted : ', decrypted	

	#print data
	toSend = raw_input("Enter message : ")
	toSend = pubsKeyObj.encrypt(toSend,0)#encrypting secret with client public key
      	encrypted =''.join(toSend)#converting encrypted tuple to string 
  	s.send(encrypted)


s.close()                  # Close the socket when done
