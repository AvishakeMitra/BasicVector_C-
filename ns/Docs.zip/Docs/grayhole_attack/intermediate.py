import socket
import random
import select

s_serv=socket.socket()
host=socket.gethostname()
port=int(raw_input("enter server port : "))
s_serv.connect((host,port))

print "connected to sv"

s_client=socket.socket()
port=int(raw_input("enter port for client : "))
s_client.bind(('0.0.0.0',port))
print "listening..."
s_client.listen(5)


while(1):
	
	c,addr=s_client.accept()
	print "got connection form ",addr
	
	while(1):
		
			r,w,x=select.select([c,s_serv],[],[])
			if c in r:
				data=c.recv(1024)
				print "recvd(from client to server): ",data
				decision=raw_input("want to drop it?(y/n) : ")
				if decision=='n':
					s_serv.send(data)
				else:
					#write_to_file(data)
					print "data dropped : ",data
			
			if s_serv in r:
				data=s_serv.recv(1024)		
				print "recvd(from server to client): ",data
				decision=raw_input("want to drop it?(y/n) : ")
				if decision=='n':
					c.send(data)
				else:
					#write_to_file(data)
					print "data dropped : ",data


