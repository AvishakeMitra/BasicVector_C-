import socket,threading

def send():
	while(1):
		msg=raw_input("enter message : ")
		c.send(msg)

def recv():
	while(1):
		data=c.recv(1024)
		print "\nclient: ",data

s=socket.socket()
host=socket.gethostname()
port=int(raw_input("enter port : "))
s.bind((host,port))

print "listening..."
s.listen(5)
c,addr=s.accept()
print "got connection from ",addr
print "starting threads..."

thread_send=threading.Thread(target=send)
thread_send.start()

thread_recv=threading.Thread(target=recv)
thread_recv.start()
		

