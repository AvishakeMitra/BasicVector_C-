import socket  ,threading            

def send():
	while(1):
		msg=raw_input("enter message : ")
		s.send(msg)

def recv():
	while(1):
		data=s.recv(1024)
		print "\nserver: ",data

s = socket.socket()     
host=socket.gethostname()
port = int(raw_input("enter port : "))

s.connect((host, port))
print "connected! starting threads..."

thread_send=threading.Thread(target=send)
thread_send.start()

thread_recv=threading.Thread(target=recv)
thread_recv.start()

	

