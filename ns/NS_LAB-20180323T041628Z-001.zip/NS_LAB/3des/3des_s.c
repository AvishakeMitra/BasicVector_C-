#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <openssl/des.h>
#include <openssl/rand.h>

#define BUFSIZE 1024 
/*#define IP "192.168.192.119";*/
#define PORT 3055;



int main() {

  int sfd, nsfd, portNo, n;
char ms[50];FILE *fp;
  char buffer[256];
  
  struct sockaddr_in server_addr, client_addr;
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = PORT;
  socklen_t xyz ;
  inet_aton("0.0.0.0", &server_addr.sin_addr.s_addr);
  int* caddrlen;

  sfd = socket(AF_INET, SOCK_STREAM, 0);

  //printf("after socket\n");

  bind(sfd, (struct sockaddr *) &server_addr, sizeof(server_addr));

 // printf("after bin\n");

  listen(sfd, 5);

 // printf("after lis\n");

  nsfd = accept(sfd, ((struct sockaddr *) &client_addr),&xyz);
  
  printf("CONNECTION EASTABLISHED\n");

    unsigned char in[BUFSIZE], out[BUFSIZE], back[BUFSIZE];
    unsigned char *e = out;
 
    	DES_cblock Key1 = { 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11 };
    	DES_cblock Key2 = { 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22 };
   	DES_cblock Key3 = { 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33 };
    	DES_cblock seed = { 0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10 };
    	DES_key_schedule ksh1,ksh2,ksh3;
 
    	memset(in, 0, sizeof(in));
    	memset(out, 0, sizeof(out));
	memset(back, 0, sizeof(back));
 
    	RAND_seed(seed, sizeof(DES_cblock));

	DES_set_key((C_Block *)Key1, &ksh1);
	DES_set_key((C_Block *)Key2, &ksh2);
	DES_set_key((C_Block *)Key3, &ksh3);
 	
//fscanf(fp,....);
while(1)
{
	fflush(stdin);
        printf("\nClient : ");
        //printf("Ciphertext:");
	read(nsfd, out ,sizeof(out));
	e=out;
    	while (*e) printf(" %0x", *e++);
    	printf("\n");
 
    	DES_ede3_cbc_encrypt( (unsigned char*)out, (unsigned char*)back, sizeof(out), &ksh1, &ksh2, &ksh3,&seed,DES_DECRYPT);
 
    	printf("After Decryption : %s\n", back);

	//printf("%s \nafter read\n",ms);
	puts(ms);
	fflush(stdout);

        fflush(stdin);
	printf("\nEnter Message : ");
	gets(in);
	DES_ede3_cbc_encrypt( (unsigned char*)in, (unsigned char*)out, sizeof(in), &ksh1, &ksh2, &ksh3,&seed, DES_ENCRYPT);
	write(nsfd,out,sizeof(out));

	fflush(stdout);
	
}

  /*strcpy(buffer, "Hi Pratik");*/


/*  close(sfd);
  close(nsfd);*/


  


	return 0;
}


