//Example code: A simple server side code, which echos back the received message.
//Handle multiple socket connections with select and fd_set on Linux 
#include <stdio.h> 
#include <string.h>   //strlen 
#include <stdlib.h> 
#include <openssl/aes.h>
#include <errno.h> 
#include <unistd.h>   //close 
#include <arpa/inet.h>    //close 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros 
//#define IP "192.168.193.183"
//#include <openssl/aes.h>

#define TRUE   1 
#define FALSE  0 
#define PORT 8888 							//Defining port number
struct user
{
   char name[256];
   unsigned long int level ; 
} ;

//--------------------------------------------------
//AES key for Encryption and Decryption 
const static unsigned char aes_key[]={0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF};
unsigned char iv[AES_BLOCK_SIZE]; 						//Initial vector

//Buffers for Encryption and Decryption
unsigned char enc_msg[256];
unsigned char dec_msg[256];

//Function for Encryption
void encrypt(char *sr_message,int len)
{

	
	memset(iv, 0x00, AES_BLOCK_SIZE);					//Initialising initial vector
	/* AES-128 bit CBC Encryption */
	AES_KEY enc_key;
	AES_set_encrypt_key(aes_key, sizeof(aes_key)*8, &enc_key);
	AES_cbc_encrypt(sr_message, enc_msg, len, &enc_key, iv, AES_ENCRYPT);
	//AES_encrypt(aes_input,enc_out,&enc_key);
}

//Function for decryption
void decrypt(char *server_response,int len)
{
	/* AES-128 bit CBC Decryption */
	memset(iv, 0x00, AES_BLOCK_SIZE); 					//Initialising vector
	
	AES_KEY dec_key;
	AES_set_decrypt_key(aes_key, sizeof(aes_key)*8, &dec_key); 		// Size of key is in bits
	AES_cbc_encrypt(server_response, dec_msg, len, &dec_key, iv, AES_DECRYPT);

}
//----------------------

unsigned long hash(unsigned char *str)
{
    unsigned long hash = 5381;
    int c;

    while (c = *str++)
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */

    return hash;
}
int main(int argc , char *argv[])  
{  
FILE *t,*p,*q;
struct user e,e1,e2;
int n;

char msg[256];
unsigned int long a;
    int len ;
    int opt = TRUE;  
    int master_socket , addrlen , new_socket , client_socket[30] , 
          max_clients = 30 , activity, i , valread , sd;  
    int max_sd; 
	int j,k; 
    struct sockaddr_in address;  
        
    char buffer[1025];  //data buffer of 1K 
        
    //set of socket descriptors 
    fd_set readfds;  
        
    //a message 
    char *message = "ECHO Daemon v1.0 \r\n";  
 p = fopen("user.txt", "w");
  
  	printf("enter initial number of usernames ");
  	scanf("%d",&n);
   		for(i=0;i<n;i++)
   			{
   				printf("Enter user Name and password");
   				scanf("%s %s", e.name, msg);
				a=hash(msg);
				e.level=a;
   				fprintf(p," %s %lu", e.name, e.level);
   			}

fclose(p);
   q = fopen("user.txt", "r");
   do
   {
      fscanf(q,"%s %lu", &e.name, &e.level);
      printf("%s %lu\n", e.name, e.level);
   }
   while( !feof(q) );
   fclose(q);
    
    //initialise all client_socket[] to 0 so not checked 
    for (i = 0; i < max_clients; i++)  
    {  
        client_socket[i] = 0;  
    }  
        
    //create a master socket 
    if( (master_socket = socket(AF_INET , SOCK_STREAM , 0)) == 0)  
    {  
        perror("socket failed");  
        exit(EXIT_FAILURE);  
    }  
    
    //set master socket to allow multiple connections , 
    //this is just a good habit, it will work without this 
    if( setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, 
          sizeof(opt)) < 0 )  
    {  
        perror("setsockopt");  
        exit(EXIT_FAILURE);  
    }  
    
    //type of socket created 
    address.sin_family = AF_INET;
    address.sin_port = htons( PORT );   
    address.sin_addr.s_addr = INADDR_ANY;
   // inet_aton(IP,&adrdress.sin_addr)  
     
        
    //bind the socket to localhost port 8888 
    if (bind(master_socket, (struct sockaddr *)&address, sizeof(address))<0)  
    {  
        perror("bind failed");  
        exit(EXIT_FAILURE);  
    }  
    printf("Listener on port %d \n", PORT);  
        
    //try to specify maximum of 3 pending connections for the master socket 
    if (listen(master_socket, 3) < 0)  
    {  
        perror("listen");  
        exit(EXIT_FAILURE);  
    }  
        
    //accept the incoming connection 
    addrlen = sizeof(address);  
    puts("Waiting for connections ...");  
        
	




     
        //clear the socket set 
        FD_ZERO(&readfds);  
    
        //add master socket to set 
        FD_SET(master_socket, &readfds);  
        max_sd = master_socket;  
            
        //add child sockets to set 
        for ( i = 0 ; i < max_clients ; i++)  
        {  
            //socket descriptor 
            sd = client_socket[i];  
                
            //if valid socket descriptor then add to read list 
            if(sd > 0)  
                FD_SET( sd , &readfds);  
                
            //highest file descriptor number, need it for the select function 
            if(sd > max_sd)  
                max_sd = sd;  
        }  
    
        //wait for an activity on one of the sockets , timeout is NULL , 
        //so wait indefinitely 
        activity = select( max_sd + 1 , &readfds , NULL , NULL , NULL);  
      
        if ((activity < 0) && (errno!=EINTR))  
        {  
            printf("select error");  
        }  
            
        //If something happened on the master socket , 
        //then its an incoming connection 
        if (FD_ISSET(master_socket, &readfds))  
        {  
            if ((new_socket = accept(master_socket, 
                    (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)  
            {  
                perror("accept");  
                exit(EXIT_FAILURE);  
            }  
            
            
            //add new socket to array of sockets 
            for (i = 0; i < max_clients; i++)  
            {  
                //if position is empty 
                if( client_socket[i] == 0 )  
                {  
                    client_socket[i] = new_socket;  
                    printf("Adding to list of sockets as %d\n" , i);  
                        
                    break;  
                }  
            }  
		
	}
	  
            sd = client_socket[i];  
		
	
			recv(sd,e2.name,256,0);
			printf("\n %s", e2.name);
			recv(sd,msg,256,0);
			printf("%s",msg);

		a=hash(msg);
		 printf(" %lu\n",a);
		e2.level=a;
		 printf("%lu\n",e2.level);

		q = fopen("user.txt", "r");
		do 

		   {
		      fscanf(q,"%s %lu",&e1.name, &e1.level);
			printf("%s %lu", e1.name, e1.level);
		   if((strcmp(e2.name,e1.name)==0)&& (e2.level==e1.level))
		     	{
			printf("\n user authenticated");
		     goto l1;
		
			}
		   }
			while( !feof(q) );
			goto l2;


	l1:
			while(1)
			{	
			
			char client_response[256];
			recv(sd,&client_response,sizeof(client_response),0);
			len=strlen(client_response);

			decrypt(client_response,strlen(client_response));	
	
			printf("message from client:  %s",client_response);
			printf("\nserver_decrypted : %s\n",dec_msg);					
			char buffer1[256];
			printf("\n enter message:  ");	
			scanf("%s",buffer1);		
		
			len=strlen(buffer1);
			encrypt(buffer1,strlen(buffer1));
			send(sd,enc_msg,sizeof(enc_msg),0);	
			}
l2: printf("\nenter correct user name and password");
	//Closing socket
	close(sd);									
	
        
    return 0;  
}  
