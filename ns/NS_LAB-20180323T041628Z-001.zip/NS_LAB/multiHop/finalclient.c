#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <openssl/aes.h>
#include <netdb.h> 
//------------------------------------------------------
/* AES key for Encryption and Decryption */
const static unsigned char aes_key[]={0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF};
unsigned char iv[AES_BLOCK_SIZE];					//Initial vector

//Buffers for Encryption and Decryption
unsigned char enc_msg[256];
unsigned char dec_msg[256];

void encrypt(char *sr_msg,int len)
{
 
  	memset(iv, 0x00, AES_BLOCK_SIZE);			 	// Initialising initial vector 
	/* AES-128 bit CBC Encryption */
	AES_KEY enc_key;
	AES_set_encrypt_key(aes_key, sizeof(aes_key)*8, &enc_key);
	AES_cbc_encrypt(sr_msg, enc_msg, len, &enc_key, iv, AES_ENCRYPT);
	
}
void decrypt(char *sr_msg,int len)
{
	
	memset(iv, 0x00, AES_BLOCK_SIZE); 			 	// Initialising vector
	/* AES-128 bit CBC Decryption */
	AES_KEY dec_key;
	AES_set_decrypt_key(aes_key, sizeof(aes_key)*8, &dec_key);      // Size of key is in bits
	AES_cbc_encrypt(sr_msg, dec_msg, len, &dec_key, iv, AES_DECRYPT);
	
}

//------------------------------------------------------------


int main(int argc, char *argv[])
{
    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    char buffer[256];
    if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
    portno = atoi(argv[2]);  //gets the port number
    sockfd = socket(AF_INET, SOCK_STREAM, 0);  //create socket for client
   
    server = gethostbyname(argv[1]);   //gets the ip address of server
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr));
     
	char buffer1[256];
	char buffer2[256];
	printf("enter the username");
	scanf("%s",buffer1);
	send(sockfd,buffer1,256,0);

	printf("enter the password");
	scanf("%s",buffer1);
	send(sockfd,buffer1,256,0);
	



	 while(1)
{
    printf("Please enter the message: ");
    scanf("%s",buffer1);
	encrypt(buffer1,strlen(buffer1)); 
    send(sockfd,enc_msg,sizeof(enc_msg),0);	
	//write(sockfd,buffer1,strlen(buffer1));
    

   
   
	//read(sockfd,buffer2,255);
   recv(sockfd,&buffer2,sizeof(buffer2),0);
	decrypt(buffer2,strlen(buffer2));				//decryting message of buf1 into dec_msg

    printf("message from server: %s \n",buffer2);
	printf("Server_decrypted : %s\n",dec_msg);		//printing decrypted message from server

    
}
//close(sockfd);
    return 0;
}
