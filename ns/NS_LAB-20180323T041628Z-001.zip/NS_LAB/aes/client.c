#include<stdio.h>
#include<netinet/in.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netdb.h>
#include<string.h>
#include<stdlib.h>
#include <openssl/aes.h>  

#define MAX 80
#define PORT 43469
#define SA struct sockaddr


static const unsigned char key[] = 
{
    0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
    0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
};

void func(int sockfd)
{

unsigned char text[80];
unsigned char enc_out[80];
unsigned char dec_out[80];
 
AES_KEY enc_key, dec_key;





for(;;)
{
bzero(text,sizeof(text));
printf("\nEnter the string : ");
int n=0,i;

while((text[n++]=getchar())!='\n');
 
/*AES ENCRYPTION*/
AES_set_encrypt_key(key, 128, &enc_key);
AES_encrypt(text,  enc_out, &enc_key);

write(sockfd,enc_out,sizeof(enc_out));

bzero(text,sizeof(text));

read(sockfd,text,sizeof(text));

/*AES DECRYPTION*/
AES_set_decrypt_key(key,128,&dec_key);
AES_decrypt(text, dec_out, &dec_key);
printf("\nCIPHER TEXT : ");
 for(i=0;*(enc_out+i)!=0x00;i++)
        printf("%X ",*(enc_out+i));
//printf("\nCIPHER TEXT : %x\t",text);
printf("\nPLAIN TEXT : %s\n",dec_out);

if((strncmp(text,"exit",4))==0)
{
printf("Client Exit...\n");
break;
}
}
}

int main()
{
int sockfd,connfd;
struct sockaddr_in servaddr,cli;
sockfd=socket(AF_INET,SOCK_STREAM,0);
if(sockfd==-1)
{
printf("socket creation failed...\n");
exit(0);
}
else
printf("Socket successfully created..\n");
bzero(&servaddr,sizeof(servaddr));
servaddr.sin_family=AF_INET;
servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
servaddr.sin_port=htons(PORT);
if(connect(sockfd,(SA *)&servaddr,sizeof(servaddr))!=0)
{
printf("connection with the server failed...\n");
exit(0);
}
else
printf("connected to the server..\n");
func(sockfd);
close(sockfd);
}

