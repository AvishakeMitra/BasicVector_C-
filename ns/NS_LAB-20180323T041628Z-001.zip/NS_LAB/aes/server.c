#include<stdio.h>
#include<netinet/in.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netdb.h>
#include<stdlib.h>
#include<string.h>
#include <openssl/aes.h>

#define MAX 80
#define PORT 43469
#define SA struct sockaddr

static const unsigned char key[] = 
{
    0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
    0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
};



void func(int sockfd)
{
unsigned char text[80];
unsigned char enc_out[80];
unsigned char dec_out[80];

AES_KEY enc_key, dec_key;

int n=0,i;



for(;;)
{
bzero(text,MAX);
read(sockfd,text,sizeof(text));

AES_set_decrypt_key(key,128,&dec_key);
AES_decrypt(text, dec_out, &dec_key);

printf("\nCIPHER TEXT : ");
 for(i=0;*(text+i)!=0x00;i++)
        printf("%X ",*(text+i));
//printf("\nCIPHER TEXT : %x\t",text);
printf("\nPLAIN TEXT : %s\n",dec_out);

bzero(text,MAX);
n=0;
while((text[n++]=getchar())!='\n');

AES_set_encrypt_key(key, 128, &enc_key);
AES_encrypt(text,  enc_out, &enc_key);


write(sockfd,enc_out,sizeof(enc_out));


}
}
int main()
{
int sockfd,connfd,len;
struct sockaddr_in servaddr,cli;
sockfd=socket(AF_INET,SOCK_STREAM,0);
if(sockfd==-1)
{
printf("socket creation failed...\n");
exit(0);
}
else
printf("Socket successfully created..\n");
bzero(&servaddr,sizeof(servaddr));
servaddr.sin_family=AF_INET;
servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
servaddr.sin_port=htons(PORT);
if((bind(sockfd,(SA*)&servaddr, sizeof(servaddr)))!=0)
{
printf("socket bind failed...\n");
exit(0);
}
else
printf("Socket successfully binded..\n");
if((listen(sockfd,5))!=0)
{
printf("Listen failed...\n");
exit(0);
}
else
printf("Server listening..\n");
len=sizeof(cli);
connfd=accept(sockfd,(SA *)&cli,&len);
if(connfd<0)
{
printf("server acccept failed...\n");
exit(0);
}
else
printf("server acccept the client...\n");
func(connfd);
close(sockfd);
}


