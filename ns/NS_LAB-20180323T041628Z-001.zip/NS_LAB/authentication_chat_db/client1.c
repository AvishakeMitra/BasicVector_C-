#include<stdio.h>   //printf
#include<string.h>  //strlen
#include<sys/socket.h>  //socket
#include<arpa/inet.h>   //inet_addr
#include <openssl/des.h>
#include <openssl/rand.h>
#define BUFSIZE 1024 

int main(int argc , char *argv[])
{
char ms[50];
    int sock,i=0,username_counter=0;
    struct sockaddr_in server;
    char message[1000] , server_reply[2000],server_reply1[2000];

    //Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons( 8888 );

    //Connect to remote server
    connect(sock , (struct sockaddr *)&server , sizeof(server)) ;

    puts("Connected\n");

    while(1)
    {
        recv(sock,server_reply,2000,0); //rec username
        puts(server_reply);
        scanf("%s",message);
        send(sock,message,strlen(message),0);
        memset(&server_reply[0], 0, sizeof(server_reply));

        recv(sock,server_reply,2000,0); //recv password
        puts(server_reply);
        scanf("%s",message);
        send(sock,message,strlen(message),0);
        memset(&server_reply[0], 0, sizeof(server_reply));

        recv(sock,server_reply,2000,0); //auth
        puts(server_reply);
    

    //keep communicating with server
     	unsigned char in[BUFSIZE], out[BUFSIZE], back[BUFSIZE];
    	unsigned char *e = out;
 
	DES_cblock key;
    	DES_cblock seed = {0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10};
    	DES_key_schedule keysched;
 
    	memset(in, 0, sizeof(in));
    	memset(out, 0, sizeof(out));
    	memset(back, 0, sizeof(back));
 
    	RAND_seed(seed, sizeof(DES_cblock));

        DES_string_to_key("abcd",&key);
	DES_set_key((C_Block *)key, &keysched);

  	while(1)
	{
		fflush(stdin);
		printf("\nEnter Message : ");
		gets(in);
                DES_cbc_encrypt((unsigned char*)in,(unsigned char*)out,sizeof(in), &keysched,&seed, DES_ENCRYPT);
		write(sock,out,sizeof(out));
		fflush(stdout);
		fflush(stdin);
		read(sock, out ,sizeof(out));
        	printf("\nServer : ");
		//printf("Ciphertext:");
                e=out;
    		while (*e) printf(" [%02x]", *e++);
    		printf("\n");
                
    		DES_cbc_encrypt((unsigned char*)out,(unsigned char*)back,sizeof(out), &keysched,&seed, DES_DECRYPT);
 
    		printf("After Decryption: [%s]\n", back);
		
		fflush(stdout);
        }
    }
    close(sock);
    return 0;
}
