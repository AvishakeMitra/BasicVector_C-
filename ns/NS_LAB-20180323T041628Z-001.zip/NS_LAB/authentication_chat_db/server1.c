#include<stdio.h>
#include<string.h>  //strlen
#include<sys/socket.h>
#include<arpa/inet.h>   //inet_addr
#include<unistd.h>  //write
#include <openssl/des.h>
#include <openssl/rand.h>

#define BUFSIZE 1024 

struct client_struct{
    char ip[20];
    char username[20];
    char password[20];
    int busy;
    int online;
    int user_number;

};
struct client_struct client_database[25];
char users_online[20][20];
int user_count=0;
int main(int argc , char *argv[])
{
char ms[50];
 int socket_desc , client_sock , c , read_size,i,j=0,not_valid=1,l;
    struct sockaddr_in server , client;
    char client_message[2000],username_database[25][25],password_database[25][25],str[INET_ADDRSTRLEN],username[20],password[20],garbage[20];
    unsigned long clients[25];

   /* strcpy(client_database[0].username,"anmol");
    strcpy(client_database[0].password,"agni");
    strcpy(client_database[1].username,"avni");
    strcpy(client_database[1].password,"jain");
    strcpy(client_database[2].username,"network");
    strcpy(client_database[2].password,"security");*/
  
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");

    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons( 8888 );

    //Bind
    bind(socket_desc,(struct sockaddr *)&server , sizeof(server)); 
 

    //Listen
    listen(socket_desc , 3);

    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);

    //accept connection from an incoming client
    while(1)
    {
        client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
        //Incrementing usercount
        inet_ntop(AF_INET, &(client.sin_addr), str, INET_ADDRSTRLEN); //extracting ip address
        printf("%s\n", str); // prints "192.0.2.33
        if (client_sock < 0)
            {
                perror("accept failed");
                return 1;
            }
            puts("Connection accepted");
            //User authentication
            write(client_sock,"Please enter username:",strlen("Please enter username\n"));
            recv(client_sock,username,20,0);

            write(client_sock,"Please enter password:",strlen("Please enter password\n"));
            recv(client_sock,password,20,0);

            //Authentication

          /*  for(j=0;j<3;j++)
            {
                //printf("%s %s %s %s\n",client_database[j].username,username,client_database[j].password,password);
                if(!(strcmp(client_database[j].username,username)) ||
                    !(strcmp(client_database[j].password,password)))
                {
                    printf("yay!\n");
                    write(client_sock,"Authenticated\n",strlen("Authenticated\n"));
                    not_valid=0;
                    break;

                }

            }*/
 	FILE *fp;
 	fp=fopen("pass.txt","r");
 	char uname[10],pass[10];
 	while(!feof(fp))
 	{
   	   fscanf(fp,"%s %s",uname,pass);
  	   if(!strcmp(uname,username) || !strcmp(pass,password))
		{
		    printf("yay!\n");
                    write(client_sock,"Authenticated\n",strlen("Authenticated\n"));
                    not_valid=0;
                    break;
		}

 	}

          if(not_valid==0)
       	  {
                unsigned char in[BUFSIZE], out[BUFSIZE], back[BUFSIZE];
    		unsigned char *e = out;
 
    		DES_cblock key;
    		DES_cblock seed = {0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10};
    		DES_key_schedule keysched;
 
    		memset(in, 0, sizeof(in));
    		memset(out, 0, sizeof(out));
    		memset(back, 0, sizeof(back));
 
    		RAND_seed(seed, sizeof(DES_cblock));
	 	DES_string_to_key("abcd",&key);
		DES_set_key((C_Block *)key, &keysched);
 	

       		while(1)
       		{
			fflush(stdin);
        		printf("\nClient : ");
        		//printf("Ciphertext:");
			read(client_sock, out ,sizeof(out));
			e=out;
    			while (*e) printf(" [%02x]", *e++);
    			printf("\n");
 
    			DES_cbc_encrypt((unsigned char*)out,(unsigned char*)back,sizeof(out), &keysched,&seed, DES_DECRYPT);
 
    			printf("After Decryption : [%s]\n", back);


			puts(ms);
			fflush(stdout);

        		fflush(stdin);
			printf("\nEnter Message : ");
			gets(in);
			DES_cbc_encrypt((unsigned char*)in,(unsigned char*)out,sizeof(in), &keysched,&seed, DES_ENCRYPT);
			write(client_sock,out,sizeof(out));

			fflush(stdout);
	
       		}
         }
	else
  	    return 0;

         
    }
    return 0;
}
