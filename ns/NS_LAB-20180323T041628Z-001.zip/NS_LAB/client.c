#include<stdio.h>
#include<netinet/in.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netdb.h>
#include<string.h>
#include<stdlib.h>
#include <openssl/des.h>
#define MAX 80
#define PORT 43468
#define SA struct sockaddr
void func(int sockfd)
{
char input[MAX];
char output[MAX];
int n;

DES_cblock key;
DES_string_to_key("pass", &key);
DES_key_schedule schedule;
DES_set_key_checked(&key, &schedule); 

for(;;)
{
bzero(input,sizeof(input));
printf("\nEnter the string : ");
n=0;
while((input[n++]=getchar())!='\n');
DES_ecb_encrypt(&input, &output, &schedule, DES_ENCRYPT);

write(sockfd,output,sizeof(output));
bzero(input,sizeof(input));
read(sockfd,input,sizeof(input));
DES_ecb_encrypt(&input, &output, &schedule, DES_DECRYPT);

printf("\nCIPHER TEXT : %x\t",input);
printf("\nPLAIN TEXT : %s\n",output);

if((strncmp(input,"exit",4))==0)
{
printf("Client Exit...\n");
break;
}
}
}

int main()
{
int sockfd,connfd;
struct sockaddr_in servaddr,cli;
sockfd=socket(AF_INET,SOCK_STREAM,0);
if(sockfd==-1)
{
printf("socket creation failed...\n");
exit(0);
}
else
printf("Socket successfully created..\n");
bzero(&servaddr,sizeof(servaddr));
servaddr.sin_family=AF_INET;
servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
servaddr.sin_port=htons(PORT);
if(connect(sockfd,(SA *)&servaddr,sizeof(servaddr))!=0)
{
printf("connection with the server failed...\n");
exit(0);
}
else
printf("connected to the server..\n");
func(sockfd);
close(sockfd);
}

